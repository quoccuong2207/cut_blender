bl_info = {
    "name": "KitCut Standard - Cắt Tách & Khớp Âm Dương In 3D",
    "author": "KitCut Studio",
    "version": (1, 0, 1),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar (N) > KitCut Std",
    "description": "Cắt tách mô hình in 3D theo đường cong/rãnh, tạo khớp Mộng Chốt (âm-dương) & Hốc Lõm giấu viền, xem trước trực quan và xuất STL hàng loạt",
    "category": "Mesh",
}

from .core import register, unregister
